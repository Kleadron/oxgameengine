using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace EffectCompiler
{
    class Program
    {
        private static string ConvertBytoToString(byte[] bytes)
        {
            StringBuilder converted = new StringBuilder();

            int i;
            for (i = 0; i < bytes.Length - 1; i++ )
                converted.AppendFormat(string.Format("{0}, ", bytes[i]));
            converted.AppendFormat(string.Format("{0}\n", bytes[i]));

            return converted.ToString();
        }

        private static void CompileEffect(string filePath)
        {
            System.Console.WriteLine("Compiling effect: " + filePath + "\n");

            CompiledEffect xboxEffect = Effect.CompileEffectFromFile("SkinnedModelEffect.fx",
                null, null, CompilerOptions.None,
                TargetPlatform.Xbox360);

            CompiledEffect windowsEffect = Effect.CompileEffectFromFile("SkinnedModelEffect.fx",
                null, null, CompilerOptions.None,
                TargetPlatform.Windows);

            // Log error messages
            System.Console.WriteLine("Xbox:\n" + xboxEffect.ErrorsAndWarnings);
            System.Console.WriteLine("Windows:\n" + xboxEffect.ErrorsAndWarnings);

            if (xboxEffect.Success && windowsEffect.Success)
            {
                string bytecode = "internal static byte[] Code = new byte[] {\n" + 
                    "#if XBOX360\n" +
                    ConvertBytoToString(xboxEffect.GetEffectCode()) + 
                    "#else\n" +
                    ConvertBytoToString(windowsEffect.GetEffectCode()) + 
                    "#endif\n};\n";

                Clipboard.SetText(bytecode);
                
                MessageBox.Show("Effect compiled successfully. Bytecodes copied to the clipboard.", 
                    "Success", MessageBoxButtons.OK, MessageBoxIcon.None, 
                    MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            }
            else
                MessageBox.Show("Error compiling effect.", "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.None, MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.DefaultDesktopOnly);
                
        }

        [STAThread]
        static void Main(string[] args)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "Effect Files (*.fx)|*.fx";
            openDialog.Multiselect = false;
            if (openDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openDialog.FileName;
                CompileEffect(filePath);
            }
        }
    }
}
