/*
 * GraphicsDeviceManagerTest.cs
 * Author: Bruno Evangelista
 * Copyright (c) 2008 Bruno Evangelista. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * 
 */
using System;
using Microsoft.Xna.Framework.Graphics;

namespace XNAnimationTest
{
    public static class GraphicsDeviceManagerTest
    {
        private static WinFormTest testForm;
        private static GraphicsDevice instance = null;

        private static GraphicsDevice CreateGraphicsDevice()
        {
            testForm = new WinFormTest();
            //testForm.Show();

            PresentationParameters pp = new PresentationParameters();
            pp.BackBufferCount = 1;
            pp.BackBufferFormat = SurfaceFormat.Color;
            pp.BackBufferWidth = 800;
            pp.BackBufferHeight = 600;
            pp.EnableAutoDepthStencil = true;
            pp.AutoDepthStencilFormat = DepthFormat.Depth24Stencil8;
            pp.IsFullScreen = false;
            pp.SwapEffect = SwapEffect.Discard;
            pp.PresentationInterval = PresentInterval.Default;
            pp.DeviceWindowHandle = testForm.Handle;

            return
                new GraphicsDevice(GraphicsAdapter.DefaultAdapter, DeviceType.Hardware,
                    (IntPtr) testForm.Handle, pp);
        }

        public static GraphicsDevice GetDevice()
        {
            if (instance == null)
            {
                instance = CreateGraphicsDevice();
            }

            return instance;
        }
    }
}