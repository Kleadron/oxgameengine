using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using XNAnimation.Effects;

namespace XNAnimationTest
{
    [DebuggerStepThrough()]
    [GeneratedCode("Microsoft.VisualStudio.TestTools.UnitTestGeneration", "1.0.0.0")]
    internal class BaseAccessor
    {
        protected PrivateObject privateObject;

        protected BaseAccessor(object target, PrivateType type)
        {
            privateObject = new PrivateObject(target, type);
        }

        protected BaseAccessor(PrivateType type)
            : this(null, type)
        {
        }

        internal virtual object Target
        {
            get { return privateObject.Target; }
        }

        public override string ToString()
        {
            return Target.ToString();
        }

        public override bool Equals(object obj)
        {
            if (typeof (BaseAccessor).IsInstanceOfType(obj))
            {
                obj = ((BaseAccessor) (obj)).Target;
            }
            return Target.Equals(obj);
        }

        public override int GetHashCode()
        {
            return Target.GetHashCode();
        }
    }


    [DebuggerStepThrough()]
    [GeneratedCode("Microsoft.VisualStudio.TestTools.UnitTestGeneration", "1.0.0.0")]
    internal class SkinnedModelEffectAccessor : BaseAccessor
    {
        protected static PrivateType privateType = new PrivateType(typeof (SkinnedModelBasicEffect));

        internal SkinnedModelEffectAccessor(SkinnedModelBasicEffect target)
            : base(target, privateType)
        {
        }

        internal static int MaxSupportedBones
        {
            get
            {
                int ret = ((int) (privateType.GetStaticField("MaxSupportedBones")));
                return ret;
            }
            set { privateType.SetStaticField("MaxSupportedBones", value); }
        }

        internal static int MaxSupportedLights
        {
            get
            {
                int ret = ((int) (privateType.GetStaticField("MaxSupportedLights")));
                return ret;
            }
            set { privateType.SetStaticField("MaxSupportedLights", value); }
        }

        internal Matrix viewMatrix
        {
            get
            {
                Matrix ret = ((Matrix) (privateObject.GetField("viewMatrix")));
                return ret;
            }
            set { privateObject.SetField("viewMatrix", value); }
        }

        internal Matrix projectionMatrix
        {
            get
            {
                Matrix ret = ((Matrix) (privateObject.GetField("projectionMatrix")));
                return ret;
            }
            set { privateObject.SetField("projectionMatrix", value); }
        }

        internal bool lightEnabled
        {
            get
            {
                bool ret = ((bool) (privateObject.GetField("lightEnabled")));
                return ret;
            }
            set { privateObject.SetField("lightEnabled", value); }
        }

        internal EffectParameter worldParam
        {
            get
            {
                EffectParameter ret = ((EffectParameter) (privateObject.GetField("worldParam")));
                return ret;
            }
            set { privateObject.SetField("worldParam", value); }
        }

        internal EffectParameter viewInverseParam
        {
            get
            {
                EffectParameter ret = ((EffectParameter) (privateObject.GetField("viewInverseParam")));
                return ret;
            }
            set { privateObject.SetField("viewInverseParam", value); }
        }

        internal EffectParameter viewProjectionParam
        {
            get
            {
                EffectParameter ret = ((EffectParameter) (privateObject.GetField("viewProjectionParam")));
                return ret;
            }
            set { privateObject.SetField("viewProjectionParam", value); }
        }

        internal EffectParameter bonesParam
        {
            get
            {
                EffectParameter ret = ((EffectParameter) (privateObject.GetField("bonesParam")));
                return ret;
            }
            set { privateObject.SetField("bonesParam", value); }
        }

        internal EffectParameter diffuseTextureEnabledParam
        {
            get
            {
                EffectParameter ret =
                    ((EffectParameter) (privateObject.GetField("diffuseTextureEnabledParam")));
                return ret;
            }
            set { privateObject.SetField("diffuseTextureEnabledParam", value); }
        }

        internal Material material
        {
            get
            {
                Material ret = ((Material) (privateObject.GetField("material")));
                return ret;
            }
            set { privateObject.SetField("material", value); }
        }

        internal EffectParameter diffuseTexture
        {
            get
            {
                EffectParameter ret = ((EffectParameter) (privateObject.GetField("diffuseTexture")));
                return ret;
            }
            set { privateObject.SetField("diffuseTexture", value); }
        }

        internal EffectParameter ambientLightColorParam
        {
            get
            {
                EffectParameter ret =
                    ((EffectParameter) (privateObject.GetField("ambientLightColorParam")));
                return ret;
            }
            set { privateObject.SetField("ambientLightColorParam", value); }
        }

        internal EnabledLights enabledLights
        {
            get
            {
                EnabledLights ret = ((EnabledLights) (privateObject.GetField("enabledLights")));
                return ret;
            }
            set { privateObject.SetField("enabledLights", value); }
        }

        internal PointLightCollection pointLightCollection
        {
            get
            {
                PointLightCollection ret =
                    ((PointLightCollection) (privateObject.GetField("pointLightCollection")));
                return ret;
            }
            set { privateObject.SetField("pointLightCollection", value); }
        }

        internal void CacheEffectParams()
        {
            object[] args = new object[0];
            privateObject.Invoke("CacheEffectParams", new Type[0], args);
        }

        internal void InitializeEffectParams()
        {
            object[] args = new object[0];
            privateObject.Invoke("InitializeEffectParams", new Type[0], args);
        }

        internal void UpdateTechnique()
        {
            object[] args = new object[0];
            privateObject.Invoke("UpdateTechnique", new Type[0], args);
        }
    }
}