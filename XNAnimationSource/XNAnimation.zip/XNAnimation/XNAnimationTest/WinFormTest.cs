using System.Windows.Forms;

namespace XNAnimationTest
{
    public partial class WinFormTest : Form
    {
        public WinFormTest()
        {
            InitializeComponent();
        }
    }
}