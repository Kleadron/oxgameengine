/*
 * SkinnedModelEffectTest.cs
 * Author: Bruno Evangelista
 * Copyright (c) 2008 Bruno Evangelista. All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * 
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using XNAnimation.Effects;

namespace XNAnimationTest
{
    /// <summary>
    ///This is a test class for SkinnedModelSystem.Effects.SkinnedModelBasicEffect and is intended
    ///to contain all SkinnedModelSystem.Effects.SkinnedModelBasicEffect Unit Tests
    ///</summary>
    [TestClass]
    public class SkinnedModelEffectTest
    {
        public static int TestLoopCount = 10;

        private TestContext testContextInstance;

        private Random randomGenerator;
        private SkinnedModelBasicEffect skinnedModelBasicEffect;
        private PrivateObject privateSkinnedModelEffect;

        #region Properties

        public TestContext TestContext
        {
            get { return testContextInstance; }
            set { testContextInstance = value; }
        }

        #endregion

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        [TestInitialize]
        public void TestInitialize()
        {
            skinnedModelBasicEffect = new SkinnedModelBasicEffect(GraphicsDeviceManagerTest.GetDevice(), null);
            privateSkinnedModelEffect = new PrivateObject(skinnedModelBasicEffect);

            randomGenerator = new Random();
        }

        [TestMethod]
        public void EffectParametersTest()
        {
            EffectParameter worldParam =
                (EffectParameter) privateSkinnedModelEffect.GetField("worldParam");
            EffectParameter viewInverseParam =
                (EffectParameter) privateSkinnedModelEffect.GetField("viewInverseParam");
            EffectParameter viewProjectionParam =
                (EffectParameter) privateSkinnedModelEffect.GetField("viewProjectionParam");
            EffectParameter bonesParam =
                (EffectParameter) privateSkinnedModelEffect.GetField("bonesParam");
            EffectParameter diffuseTextureEnabledParam =
                (EffectParameter) privateSkinnedModelEffect.GetField("diffuseTextureEnabledParam");
            EffectParameter diffuseTextureParam =
                (EffectParameter) privateSkinnedModelEffect.GetField("diffuseTextureParam");
            EffectParameter ambientLightColorParam =
                (EffectParameter) privateSkinnedModelEffect.GetField("ambientLightColorParam");

            Assert.AreNotEqual(worldParam, null);
            Assert.AreNotEqual(viewInverseParam, null);
            Assert.AreNotEqual(viewProjectionParam, null);
            Assert.AreNotEqual(bonesParam, null);
            Assert.AreNotEqual(diffuseTextureEnabledParam, null);
            Assert.AreNotEqual(diffuseTextureParam, null);
            Assert.AreNotEqual(ambientLightColorParam, null);
        }

        [TestMethod]
        public void EffectParametersMaterialTest()
        {
            PrivateObject privateMaterial = new PrivateObject(skinnedModelBasicEffect.Material);
            EffectParameter emissiveColorParam =
                (EffectParameter) privateMaterial.GetField("emissiveColorParam");
            EffectParameter diffuseColorParam =
                (EffectParameter) privateMaterial.GetField("diffuseColorParam");
            EffectParameter specularColorParam =
                (EffectParameter) privateMaterial.GetField("specularColorParam");
            EffectParameter specularPowerParam =
                (EffectParameter) privateMaterial.GetField("specularPowerParam");

            Assert.AreNotEqual(emissiveColorParam, null);
            Assert.AreNotEqual(diffuseColorParam, null);
            Assert.AreNotEqual(specularColorParam, null);
            Assert.AreNotEqual(specularPowerParam, null);
        }

        [TestMethod]
        public void EffectParametersLightTest()
        {
            for (int i = 0; i < SkinnedModelBasicEffect.MaxSupportedLights; i++)
            {
                PrivateObject privateLight = new PrivateObject(skinnedModelBasicEffect.PointLights[i]);

                EffectParameter positionParam = (EffectParameter) privateLight.GetField("positionParam");
                EffectParameter colorParam = (EffectParameter) privateLight.GetField("colorParam");
                EffectParameter rangeParam = (EffectParameter) privateLight.GetField("rangeParam");
                EffectParameter fallofParam = (EffectParameter) privateLight.GetField("fallofParam");

                Assert.AreNotEqual(positionParam, null);
                Assert.AreNotEqual(colorParam, null);
                Assert.AreNotEqual(rangeParam, null);
                Assert.AreNotEqual(fallofParam, null);
            }
        }

        [TestMethod]
        public void MatrixParamsTest()
        {
            for (int i = 0; i < TestLoopCount; i++)
            {
                Matrix worldMatrix =
                    Matrix.CreateFromYawPitchRoll(randomGenerator.Next(10), randomGenerator.Next(10),
                        randomGenerator.Next(10));
                Matrix viewMatrix =
                    Matrix.CreateFromYawPitchRoll(randomGenerator.Next(10), randomGenerator.Next(10),
                        randomGenerator.Next(10));
                Matrix projectionMatrix =
                    Matrix.CreateFromYawPitchRoll(randomGenerator.Next(10), randomGenerator.Next(10),
                        randomGenerator.Next(10));

                //skinnedModelBasicEffect.World = worldMatrix;
                skinnedModelBasicEffect.View = viewMatrix;
                skinnedModelBasicEffect.Projection = projectionMatrix;

                //Assert.AreEqual(skinnedModelBasicEffect.World, worldMatrix);
                Assert.AreEqual(skinnedModelBasicEffect.View, viewMatrix);
                Assert.AreEqual(skinnedModelBasicEffect.Projection, projectionMatrix);
            }
        }

        [TestMethod]
        public void MaterialParamsTest()
        {
            for (int i = 0; i < TestLoopCount; i++)
            {
                Vector3 colorValue1 = new Vector3((float) randomGenerator.NextDouble());
                Vector3 colorValue2 = new Vector3((float) randomGenerator.NextDouble());
                Vector3 colorValue3 = new Vector3((float) randomGenerator.NextDouble());
                float floatValue = (float) randomGenerator.NextDouble();

                skinnedModelBasicEffect.Material.EmissiveColor = colorValue1;
                skinnedModelBasicEffect.Material.DiffuseColor = colorValue2;
                skinnedModelBasicEffect.Material.SpecularColor = colorValue3;
                skinnedModelBasicEffect.Material.SpecularPower = floatValue;

                Assert.AreEqual(skinnedModelBasicEffect.Material.EmissiveColor, colorValue1);
                Assert.AreEqual(skinnedModelBasicEffect.Material.DiffuseColor, colorValue2);
                Assert.AreEqual(skinnedModelBasicEffect.Material.SpecularColor, colorValue3);
                Assert.AreEqual(skinnedModelBasicEffect.Material.SpecularPower, floatValue);
            }

            skinnedModelBasicEffect.DiffuseMapEnabled = true;
            Assert.AreEqual(skinnedModelBasicEffect.DiffuseMapEnabled, true);
            skinnedModelBasicEffect.DiffuseMapEnabled = false;
            Assert.AreEqual(skinnedModelBasicEffect.DiffuseMapEnabled, false);

            Texture2D sampleTexture1 =
                new Texture2D(GraphicsDeviceManagerTest.GetDevice(), 256, 256, 1, TextureUsage.None,
                    SurfaceFormat.Color);
            Texture2D sampleTexture2 =
                new Texture2D(GraphicsDeviceManagerTest.GetDevice(), 256, 256, 1, TextureUsage.None,
                    SurfaceFormat.Color);

            skinnedModelBasicEffect.DiffuseMap = sampleTexture1;
            Assert.AreEqual(skinnedModelBasicEffect.DiffuseMap, sampleTexture1);
            skinnedModelBasicEffect.DiffuseMap = sampleTexture2;
            Assert.AreEqual(skinnedModelBasicEffect.DiffuseMap, sampleTexture2);
        }

        [TestMethod]
        public void LightParamsTest()
        {
            for (int i = 0; i < TestLoopCount; i++)
            {
                Vector3[] vectorValue1 = new Vector3[SkinnedModelBasicEffect.MaxSupportedLights];
                Vector3[] vectorValue2 = new Vector3[SkinnedModelBasicEffect.MaxSupportedLights];
                float[] floatValue1 = new float[SkinnedModelBasicEffect.MaxSupportedLights];
                float[] floatValue2 = new float[SkinnedModelBasicEffect.MaxSupportedLights];

                for (int j = 0; j < SkinnedModelBasicEffect.MaxSupportedLights; j++)
                {
                    vectorValue1[j] = new Vector3((float) randomGenerator.NextDouble());
                    vectorValue2[j] = new Vector3((float) randomGenerator.NextDouble());
                    floatValue1[j] = (float) randomGenerator.NextDouble();
                    floatValue2[j] = (float) randomGenerator.NextDouble();

                    skinnedModelBasicEffect.PointLights[j].Position = vectorValue1[j];
                    skinnedModelBasicEffect.PointLights[j].Color = vectorValue2[j];
                }

                for (int j = 0; j < SkinnedModelBasicEffect.MaxSupportedLights; j++)
                {
                    Assert.AreEqual(skinnedModelBasicEffect.PointLights[j].Position, vectorValue1[j]);
                    Assert.AreEqual(skinnedModelBasicEffect.PointLights[j].Color, vectorValue2[j]);
                }
            }
        }

        [TestMethod]
        public void InitializedDefaultParamsTest()
        {
            // TODO Test the initializes default parameters
        }

        [TestMethod]
        public void TechniqueTest()
        {
            // TODO Test if the current technique is set
        }
    }
}